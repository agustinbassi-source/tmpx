using NUnit.Framework;
using Service;
using Service.Models;

namespace TestProjectX
{
  public class Tests
  {
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void Test1()
    {
      //ReportService reportService = new ReportService();

      //var proyect = new Project()
      //{
      //  LocalDirectory= "X:\\X_XP_Viewer",
      //  RelativePath = "\\Wigos System\\WGC\\GUI",
      //  ProyectName = "GUI Test"
      //};

      //proyect.ProyectFiles.Add(new ProjectFile
      //{
      //  Namespace = "WSI.Common",
      //   ProyectClasses = { new ProjectClass { 
      //    Name = "BucketsUpdate",
      //     ProyectFunctions = { new ProjectFunction { FunctionName = "UpdateCustomerBucket" } }
      //   } }

      //});



     // reportService.BuildReport(proyect);


      
    }
  }
}